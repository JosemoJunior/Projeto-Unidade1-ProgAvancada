
public class SessaoRepetidaException extends Exception{
	
	public SessaoRepetidaException (String mensagem) {
		super(mensagem);
	}

}
