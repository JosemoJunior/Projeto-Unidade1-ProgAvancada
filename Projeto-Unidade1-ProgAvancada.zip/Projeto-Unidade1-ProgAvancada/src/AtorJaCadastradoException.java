
public class AtorJaCadastradoException extends Exception{
	
	public AtorJaCadastradoException(String mensagem) {
		super(mensagem);
	}

}

