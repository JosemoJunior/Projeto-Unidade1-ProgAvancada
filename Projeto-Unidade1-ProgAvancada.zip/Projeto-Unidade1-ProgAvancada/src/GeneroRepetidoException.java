
public class GeneroRepetidoException extends Exception{
	
	public GeneroRepetidoException(String mensagem) {
		super(mensagem);
	}

}
